OneTime Setup to execute bot

Step 1 : You need to install NodeJs software at first from below link (If you install NodeJs already ignore this step)
https://nodejs.org/en/ 

Step 2 : Open .env file with notepad and give all the necessary details.

Step 3 : Load your wallet with some AVAX for paying gas fee (what ever the chain you are using).

Step 4: This Bot is mainly sniping with WAVAX, So you have to have WAVAX for purchasing token

Step 5 : For the first time, give the purchasing token as WAVAX in .env

Step 6: Double click the run.bat file to start the bot and Approve the WBNB for sniping.

Step 7: Now are all set for sniping . Edit the .env file and give required purchasing token.




Note: This sniper is forked version of pancake sniper and tested several times on AVAX chain

If you have any doubts/questions contact me on telegram (====  @sniperbot_AVAX  =====)